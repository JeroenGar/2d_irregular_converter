Description: 
2D Irregular Strip Packing Problems (JAKOBS) from JAKOBS (1996)
Constructed from sample layout in paper Jakobs (1996) by Eva Hopper. Shapes artificially created.
(Data sets: jakobs1, jakobs2)

References: 
Jakobs, S. 1996, On genetic algorithms for the packing of polygons. European Journal of Operations Research 88, 165-181. 