Description: 
2D Irregular Strip Packing Problems (FU) from FUJITA/AKAGJI/KIROKAWA (1993)
Artificially created data set, scanned from sample layout in paper Fujita et al. (1993) by Eva Hopper.
(Data sets: fu)

References: 
Fujita, K., Akagji, S. and Kirokawa, N. 1993, Hybrid approach for optimal nesting using a genetic algorithm and a local minimisation algorithm.
Proceedings of the 19th Annual ASME Design Automation Conference, Part 1 (of 2), Albuquerque, NM, USA, vol. 65, part 1, pp. 477-484.
